import * as React from 'react';
import Box from '@mui/material/Box';
import Card from '@mui/material/Card';
import CardActions from '@mui/material/CardActions';
import CardContent from '@mui/material/CardContent';
import Typography from '@mui/material/Typography';
import { blogDatabase } from '../../../config';
import { useState ,useEffect} from 'react';
import { Link } from 'react-router-dom';
import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal';


export default function Blog() {

  const [blogs, setBlogs] = useState(blogDatabase)
  const [editBlog, setEditBlog] = useState()
  const [show, setShow] = useState(false);

  const handleClose = () => setShow(false);

  const handleShow = (id) => {
    setShow(true);
    const response = blogs?.find((blog) => blog._id === id)
    console.log(response);
    setEditBlog(response)
  };

  const editHandle = (id) => {
    handleClose()

    // useffte use for change category,title,desription
  //   useEffect(()  =>{
  //  setName(localStorage.getItem('category'))
  //  setAge(localStorage.getItem('title'))
  //  setId(localStorage.getItem('desription'))
  // },[] )

  }

  const handleChange = (e) => {
    setEditBlog({...editBlog, [e.target.name] : e.target.value})
  }

  const deleteHandle = (id) => {
    const response = blogs?.filter((blog) => blog?._id !== id)
    setBlogs(response)
  }

  return (

    <div className="container">
      <div className="row mt-5">
        {
          blogs.map((blog, index) => <div className="col-3" key={index}>
            <Box sx={{ minWidth: 275 }}>
              <Card variant="outlined"><React.Fragment>
                <CardContent>
                  <Typography sx={{ fontSize: 14 }} color="text.secondary" gutterBottom>
                    {blog.category}
                  </Typography>
                  <Typography variant="h5" component="div">
                    {blog.title}
                  </Typography>
                  <Typography sx={{ mb: 1.5 }} color="text.secondary">
                    {blog.desription}
                  </Typography>
                </CardContent>
                <CardActions>
                  <button onClick={() => handleShow(blog?._id)} class="btn btn-primary">Edit </button>
                  <button className='btn btn-danger' onClick={() => deleteHandle(blog?._id)}>Delete </button>
                </CardActions>
              </React.Fragment></Card>
            </Box>
          </div>)
        }

        <Modal show={show} onHide={handleClose}>
          <Modal.Header closeButton>
            <Modal.Title>Modal heading</Modal.Title>
          </Modal.Header>
          <Modal.Body>
          <form action="">
            <div className="form-floating mb-3">
              <input type="text" className="form-control"  placeholder='Blog Title'onChange={handleChange} name="title" value={editBlog?.title}/>
                <label htmlFor="floatingInput">Title</label>
            </div>
            <div className="form-floating mb-3">
              <input type="text" className="form-control"  placeholder='Blog Description' onChange={handleChange} name="desription" value={editBlog?.desription}/>
                <label htmlFor="floatingPassword">Description</label>
            </div>
            <div className="form-floating mb-3">
              <input type="text" className="form-control"  placeholder='Blog Category' onChange={handleChange} name="category" value={editBlog?.category}/>
                <label htmlFor="floatingPassword">Category</label>
            </div>
          </form>
          </Modal.Body>
          <Modal.Footer>
            <Button variant="secondary" onClick={handleClose}>
              Close
            </Button>
            <Button variant="primary" onClick={() => editHandle(editBlog?._id)}>
              Save Changes
            </Button>
          </Modal.Footer>
        </Modal>
      </div>
    </div>
  );
}
