import React, { useEffect, useState } from 'react'
import { useParams } from 'react-router-dom'
import { blogDatabase } from '../../../config';

const BlogSection = () => {

    const params = useParams()
    const [ blogFind, setBlogFind ] = useState(blogDatabase)
    const [ singleView, setSingerView ] = useState()

    const FindBlog = () => {
        const response = blogFind.filter((blogs) => blogs._id === params.id);
        setSingerView(response)
        console.log(response);
        localStorage.setItem("blog_ID", JSON.stringify(response[0]?._id))
    }

    useEffect(() => {
        FindBlog()
    },[])


    return (
    <div>
      {
        singleView?.map((blog, index) => <div key={index}>
            <h1>{blog.title}</h1>
        </div>)
      }
       </div>
  )
}

export default BlogSection
